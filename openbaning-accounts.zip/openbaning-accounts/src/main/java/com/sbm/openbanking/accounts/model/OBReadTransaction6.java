package com.sbm.openbanking.accounts.model;

import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.sbm.openbanking.accounts.model.OBReadAccount4.OBExternalFinancialInstitutionIdentification4Code;
import com.sbm.openbanking.accounts.model.OBReadBalance1.OBActiveOrHistoricCurrencyAndAmount;
import com.sbm.openbanking.accounts.model.OBReadBalance1.OBBalanceType1Code;
import com.sbm.openbanking.accounts.model.OBReadBalance1.OBCreditDebitCode;

import lombok.Getter;
import lombok.Setter;

@JsonRootName("OBReadTransaction6")
@Getter @Setter
public class OBReadTransaction6 implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@JsonProperty(value ="Data", required = true)
	private OBReadDataTransaction6 data = new OBReadDataTransaction6();
	
	@JsonRootName("OBReadDataTransaction6")
	@Getter @Setter
	public static class OBReadDataTransaction6 {
		
		@JsonProperty(value ="Transaction", required = false)
		@JsonPropertyDescription("Provides further details on an entry in the report.")
		private List<OBTransaction6> accountTransactions;

	}
	
	@JsonRootName("OBTransaction6")
	@Getter @Setter
	public static class OBTransaction6 {
		
		@JsonProperty(value ="AccountId", required = true)
		@JsonPropertyDescription("A unique and immutable identifier used to identify the account resource. This identifier has no meaning to the account owner.")
		@Size(min = 1, max = 13)
		@Pattern(regexp = OBPatterns.SAIB_ACCOUNT_ID)
		private String accountId;
		
		@JsonProperty(value ="TransactionId", required = false)
		@JsonPropertyDescription("Unique identifier for the transaction within an servicing institution. This identifier is both unique and immutable.")
		@Size(min = 1, max = 210)
		private String transactionId;
		
		@JsonProperty(value ="TransactionReference", required = false)
		@JsonPropertyDescription("Unique reference for the transaction. This reference is optionally populated, and may as an example be the FPID in the Faster Payments context.")
		@Size(min = 1, max = 210)
		private String transactionReference;
		
		@JsonProperty(value ="StatementReference", required = false)
		@JsonPropertyDescription("Unique reference for the statement. This reference may be optionally populated if available.")
		@Size(min = 1, max = 35)
		private List<String> statementReference;
		
		@JsonProperty(value ="CreditDebitIndicator", required = true)
		@JsonPropertyDescription("Indicates whether the transaction is a credit or a debit entry.")
		private OBCreditDebitCode creditDebitIndicator;
		
		@JsonProperty(value ="Status", required = true)
		@JsonPropertyDescription("Status of a transaction entry on the books of the account servicer.")
		private OBEntryStatus1Code status;
		
		@JsonProperty(value ="TransactionMutability", required = false)
		@JsonPropertyDescription("Specifies the Mutability of the Transaction record.")
		private OBTransactionMutability1Code transactionMutability;
		
		@JsonProperty(value ="BookingDateTime", required = true)
		@JsonPropertyDescription("Date and time when a transaction entry is posted to an account on the account servicer's books. Usage: Booking date is the expected booking date, unless the status is booked, in which case it is the actual booking date.")
		@Pattern(regexp = OBPatterns.ISODATETIME)
		private String bookingDateTime;
		
		@JsonProperty(value ="ValueDateTime", required = false)
		@JsonPropertyDescription("Date and time at which assets become available to the account owner in case of a credit entry, or cease to be available to the account owner in case of a debit transaction entry. Usage: If transaction entry status is pending and value date is present, then the value date refers to an expected/requested value date. For transaction entries subject to availability/float and for which availability information is provided, the value date must not be used. In this case the availability component identifies the number of availability days.")
		@Pattern(regexp = OBPatterns.ISODATETIME)
		private String valueDateTime;
		
		@JsonProperty(value ="TransactionInformation", required = false)
		@JsonPropertyDescription("Further details of the transaction. This is the transaction narrative, which is unstructured text.")
		@Size(min = 1, max = 500)
		private String transactionInformation;
		
		@JsonProperty(value ="AddressLine", required = false)
		@JsonPropertyDescription("Information that locates and identifies a specific address for a transaction entry, that is presented in free format text.")
		@Size(min = 1, max = 70)
		private String addressLine;
		
		@JsonProperty(value ="Amount", required = true)
		@JsonPropertyDescription("Amount of money in the cash transaction entry.")
		private OBActiveOrHistoricCurrencyAndAmount amount;
		
		@JsonProperty(value ="ChargeAmount", required = false)
		@JsonPropertyDescription("Transaction charges to be paid by the charge bearer.")
		private OBActiveOrHistoricCurrencyAndAmount chargeAmount;
		
		@JsonProperty(value ="CurrencyExchange", required = false)
		@JsonPropertyDescription("Set of elements used to provide details on the currency exchange.")
		private OBCurrencyExchange5 currencyExchange;
		
		@JsonProperty(value ="BankTransactionCode", required = false)
		@JsonPropertyDescription("Set of elements used to fully identify the type of underlying transaction resulting in an entry.")
		private OBBankTransactionCodeStructure1 bankTransactionCode;
		
		@JsonProperty(value ="ProprietaryBankTransactionCode", required = false)
		@JsonPropertyDescription("Set of elements to fully identify a proprietary bank transaction code.")
		private ProprietaryBankTransactionCodeStructure1 proprietaryBankTransactionCode;
		
		@JsonProperty(value ="Balance", required = false)
		@JsonPropertyDescription("Set of elements used to define the balance as a numerical representation of the net increases and decreases in an account after a transaction entry is applied to the account.")
		private OBTransactionCashBalance balance;
		
		@JsonProperty(value ="MerchantDetails", required = false)
		@JsonPropertyDescription("Details of the merchant involved in the transaction.")
		private OBMerchantDetails1 merchantDetails;
		
		@JsonProperty(value ="CreditorAgent", required = false)
		@JsonPropertyDescription("Financial institution servicing an account for the creditor.")
		private OBBranchAndFinancialInstitutionIdentification6 creditorAgent;
		
		@JsonProperty(value ="CreditorAccount", required = false)
		@JsonPropertyDescription("Unambiguous identification of the account of the creditor, in the case of a debit transaction.")
		private OBCashAccount6 creditorAccount;
		
		@JsonProperty(value ="DebtorAgent", required = false)
		@JsonPropertyDescription("Financial institution servicing an account for the debtor.")
		private OBBranchAndFinancialInstitutionIdentification6 debtorAgent;
		
		@JsonProperty(value ="DebtorAccount", required = false)
		@JsonPropertyDescription("Unambiguous identification of the account of the debtor, in the case of a credit transaction.")
		private OBCashAccount6 debtorAccount;
		
		@JsonProperty(value ="CardInstrument", required = false)
		@JsonPropertyDescription("Set of elements to describe the card instrument used in the transaction.")
		private OBTransactionCardInstrument1 cardInstrument;
		
		@JsonProperty(value ="SupplementaryData", required = false)
		@JsonPropertyDescription("Additional information that can not be captured in the structured fields and/or any other specific block.")
		private OBSupplementaryData1 supplementaryData;
		
	}
	
	@JsonRootName("OBCurrencyExchange5")
	@Getter @Setter
	public static class OBCurrencyExchange5 {
		
		@JsonProperty(value ="SourceCurrency", required = true)
		@JsonPropertyDescription("Currency from which an amount is to be converted in a currency conversion.")
		@Pattern(regexp = OBPatterns.CURRENCY_CODE)
		private String sourceCurrency;
		
		@JsonProperty(value ="TargetCurrency", required = false)
		@JsonPropertyDescription("Currency into which an amount is to be converted in a currency conversion.")
		@Pattern(regexp = OBPatterns.CURRENCY_CODE)
		private String targetCurrency;
		
		@JsonProperty(value ="UnitCurrency", required = false)
		@JsonPropertyDescription("Currency in which the rate of exchange is expressed in a currency exchange. In the example 1GBP = xxxCUR, the unit currency is GBP.")
		@Pattern(regexp = OBPatterns.CURRENCY_CODE)
		private String unitCurrency;
		
		@JsonProperty(value ="ExchangeRate", required = true)
		@JsonPropertyDescription("Factor used to convert an amount from one currency into another. This reflects the price at which one currency was bought with another currency.\n" + 
				"\n" + 
				"Usage: ExchangeRate expresses the ratio between UnitCurrency and QuotedCurrency (ExchangeRate = UnitCurrency/QuotedCurrency).")
		private Double exchangeRate;
		
		@JsonProperty(value ="ContractIdentification", required = false)
		@JsonPropertyDescription("Unique identification to unambiguously identify the foreign exchange contract.")
		@Size(min = 1, max = 35)
		private String contractIdentification;
		
		@JsonProperty(value ="QuotationDate", required = false)
		@JsonPropertyDescription("Date and time at which an exchange rate is quoted.")
		@Pattern(regexp = OBPatterns.ISODATETIME)
		private String quotationDate;

		@JsonProperty(value ="InstructedAmount", required = false)
		@JsonPropertyDescription("Amount of money to be moved between the debtor and creditor, before deduction of charges, expressed in the currency as ordered by the initiating party.")
		private OBActiveOrHistoricCurrencyAndAmount instructedAmount;
		
	}
	
	@JsonRootName("OBBankTransactionCodeStructure1")
	@Getter @Setter
	public static class OBBankTransactionCodeStructure1 {
		
		@JsonProperty(value ="Code", required = true)
		@JsonPropertyDescription("Specifies the family within a domain.")
		private String code;
		
		@JsonProperty(value ="SubCode", required = true)
		@JsonPropertyDescription("Specifies the sub-product family within a specific family.")
		private String subCode;
		
	}
	
	@JsonRootName("ProprietaryBankTransactionCodeStructure1")
	@Getter @Setter
	public static class ProprietaryBankTransactionCodeStructure1 {
		
		@JsonProperty(value ="Code", required = true)
		@JsonPropertyDescription("Proprietary bank transaction code to identify the underlying transaction.")
		@Size(min = 1, max = 35)
		private String code;
		
		@JsonProperty(value ="Issuer", required = false)
		@JsonPropertyDescription("Identification of the issuer of the proprietary bank transaction code.")
		@Size(min = 1, max = 35)
		private String issuer;
		
	}
	
	@JsonRootName("OBTransactionCashBalance")
	@Getter @Setter
	public static class OBTransactionCashBalance {
		
		@JsonProperty(value ="CreditDebitIndicator", required = true)
		@JsonPropertyDescription("Indicates whether the balance is a credit or a debit balance.\n" + 
				"\n" + 
				"Usage: A zero balance is considered to be a credit balance.")
		private OBCreditDebitCode creditDebitIndicator;
		
		@JsonProperty(value ="Type", required = true)
		@JsonPropertyDescription("Balance type, in a coded form.")
		private OBBalanceType1Code type;
		
		@JsonProperty(value ="Amount", required = true)
		@JsonPropertyDescription("Amount of money of the cash balance after a transaction entry is applied to the account.")
		private OBActiveOrHistoricCurrencyAndAmount amount;
	}
	
	@JsonRootName("OBMerchantDetails1")
	@Getter @Setter
	public static class OBMerchantDetails1 {
		
		@JsonProperty(value ="MerchantName", required = false)
		@JsonPropertyDescription("Name by which the merchant is known.")
		@Size(min = 1, max = 350)
		private String merchantName;
		
		@JsonProperty(value ="MerchantCategoryCode", required = false)
		@JsonPropertyDescription("Category code conform to ISO 18245, related to the type of services or goods the merchant provides for the transaction.")
		@Size(min = 3, max = 4)
		private String merchantCategoryCode;
		
	}
	
	@JsonRootName("OBPostalAddress6")
	@Getter @Setter
	public static class OBPostalAddress6 {
		
		@JsonProperty(value ="AddressType", required = false)
		@JsonPropertyDescription("Identifies the nature of the postal address.")
		private OBAddressTypeCode addressType;
		
		@JsonProperty(value ="Department", required = false)
		@JsonPropertyDescription("Identification of a division of a large organisation or building.")
		@Size(min = 1, max = 70)
		private String department;
		
		@JsonProperty(value ="SubDepartment", required = false)
		@JsonPropertyDescription("Identification of a sub-division of a large organisation or building.")
		@Size(min = 1, max = 70)
		private String subDepartment;
		
		@JsonProperty(value ="StreetName", required = false)
		@JsonPropertyDescription("Name of a street or thoroughfare.")
		@Size(min = 1, max = 70)
		private String streetName;
		
		@JsonProperty(value ="BuildingNumber", required = false)
		@JsonPropertyDescription("Number that identifies the position of a building on a street.")
		@Size(min = 1, max = 16)
		private String buildingNumber;
		
		@JsonProperty(value ="PostCode", required = false)
		@JsonPropertyDescription("Identifier consisting of a group of letters and/or numbers that is added to a postal address to assist the sorting of mail.")
		@Size(min = 1, max = 16)
		private String postCode;
		
		@JsonProperty(value ="TownName", required = false)
		@JsonPropertyDescription("Name of a built-up area, with defined boundaries, and a local government.")
		@Size(min = 1, max = 35)
		private String townName;
		
		@JsonProperty(value ="CountrySubDivision", required = false)
		@JsonPropertyDescription("Identifies a subdivision of a country such as state, region, county.")
		@Size(min = 1, max = 35)
		private String countrySubDivision;
		
		@JsonProperty(value ="Country", required = false)
		@JsonPropertyDescription("Nation with its own government.")
		@Pattern(regexp = OBPatterns.COUNTRY_CODE)
		private String country;
		
		@JsonProperty(value ="AddressLine", required = false)
		@JsonPropertyDescription("Information that locates and identifies a specific address, as defined by postal services, presented in free format text.")
		@Size(min = 1, max = 70)
		private String addressLine;
	}
	
	@JsonRootName("OBCashAccount6")
	@Getter @Setter
	public static class OBCashAccount6 {
		
		@JsonProperty(value ="SchemeName", required = false)
		@JsonPropertyDescription("Name of the identification scheme, in a coded form as published in an external list.")
		private String schemeName;
		
		@JsonProperty(value ="Identification", required = false)
		@JsonPropertyDescription("Identification assigned by an institution to identify an account. This identification is known by the account owner.")
		@Size(min = 1, max = 256)
		private String identification;
		
		@JsonProperty(value ="Name", required = false)
		@JsonPropertyDescription("	\n" + 
				"The account name is the name or names of the account owner(s) represented at an account level, as displayed by the ASPSP's online channels.\n" + 
				"\n" + 
				"Note, the account name is not the product name or the nickname of the account.")
		@Size(min = 1, max = 70)
		private String name;
		
		@JsonProperty(value ="SecondaryIdentification", required = false)
		@JsonPropertyDescription("This is secondary identification of the account, as assigned by the account servicing institution.\n" + 
				"\n" + 
				"This can be used by building societies to additionally identify accounts with a roll number (in addition to a sort code and account number combination).")
		@Size(min = 1, max = 34)
		private String secondaryIdentification;
	}
	
	@JsonRootName("OBTransactionCardInstrument1")
	@Getter @Setter
	public static class OBTransactionCardInstrument1 {
		
		@JsonProperty(value ="CardSchemeName", required = true)
		@JsonPropertyDescription("Name of the card scheme.")
		private OBExternalCardSchemeType1Code cardSchemeName;
		
		@JsonProperty(value ="AuthorisationType", required = false)
		@JsonPropertyDescription("The card authorisation type.")
		private OBExternalCardAuthorisationType1Code authorisationType;
		
		@JsonProperty(value ="Name", required = false)
		@JsonPropertyDescription("Name of the cardholder using the card instrument.")
		@Size(min = 1, max = 70)
		private String name;
		
		@JsonProperty(value ="Identification", required = false)
		@JsonPropertyDescription("Identification assigned by an institution to identify the card instrument used in the transaction. This identification is known by the account owner, and may be masked.")
		@Size(min = 1, max = 34)
		private String identification;
	}
	
	
	
	@JsonRootName("OBTransactionMutability1Code")
	@Getter @Setter
	public static class OBTransactionMutability1Code {
//		TODO NO OBJECT
	}
	
	@JsonRootName("OBSupplementaryData1")
	@Getter @Setter
	public static class OBSupplementaryData1 {
//		TODO NO OBJECT
	}
	
	@JsonRootName("OBBranchAndFinancialInstitutionIdentification6")
	@Getter @Setter
	public static class OBBranchAndFinancialInstitutionIdentification6 {
		
		@JsonProperty(value ="SchemeName", required = false)
		@JsonPropertyDescription("Name of the identification scheme, in a coded form as published in an external list.")
		private OBExternalFinancialInstitutionIdentification4Code schemeName;
		
		@JsonProperty(value ="Identification", required = false)
		@JsonPropertyDescription("Unique and unambiguous identification of a financial institution or a branch of a financial institution.")
		@Size(min = 1, max = 35)
		private String identification;
		
		@JsonProperty(value ="Name", required = false)
		@JsonPropertyDescription("Name by which an agent is known and which is usually used to identify that agent.")
		@Size(min = 1, max = 140)
		private String name;
		
		@JsonProperty(value ="PostalAddress", required = false)
		@JsonPropertyDescription("Information that locates and identifies a specific address, as defined by postal services.")
		private OBPostalAddress6 postalAddress;
	}
	
	public enum OBEntryStatus1Code {
		Booked, Pending
	}
	
	public enum OBAddressTypeCode {
		Business, Correspondence, DeliveryTo, MailTo, POBox, Postal, Residential, Statement
	}
	
	public enum OBExternalCardSchemeType1Code {
		AmericanExpress, Diners, Discover, MasterCard, VISA
	}
	
	public enum OBExternalCardAuthorisationType1Code {
		ConsumerDevice, Contactless, None, PIN
	}
	
}
