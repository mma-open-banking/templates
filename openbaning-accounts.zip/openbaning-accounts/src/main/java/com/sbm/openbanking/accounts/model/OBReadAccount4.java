package com.sbm.openbanking.accounts.model;

import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonRootName;

import lombok.Getter;
import lombok.Setter;

@JsonRootName("OBReadAccount4")
@Getter @Setter
public class OBReadAccount4 implements Serializable {
	private static final long serialVersionUID = 4949662200148334400L;

	@JsonProperty(value ="Data", required = true)
	private OBReadDataAccount4 data = new OBReadDataAccount4();
	
	@JsonRootName("OBReadDataAccount4")
	@Getter @Setter
	public static class OBReadDataAccount4 {
		
		@JsonProperty(value ="Account", required = false)
		@JsonPropertyDescription("Unambiguous identification of the account to which credit and debit entries are made.")
		private List<OBAccount4> accounts;
	}
	
	@JsonRootName("OBAccount4")
	@Getter @Setter
	public static class OBAccount4 {
		
		@JsonProperty(value ="AccountId", required = true)
		@JsonPropertyDescription("A unique and immutable identifier used to identify the account resource. This identifier has no meaning to the account owner.")
		@Size(min = 1, max = 13)
		@Pattern(regexp = OBPatterns.SAIB_ACCOUNT_ID)
		private String accountId;

		@JsonProperty(value ="Status", required = false)
		@JsonPropertyDescription("Specifies the status of account resource in code form.")
		private OBAccountStatus1Code status;
		
		@JsonProperty(value ="StatusUpdateDateTime", required = false)
		@JsonPropertyDescription("Date and time at which the resource status was updated.All dates in the JSON payloads are represented in ISO 8601 date-time format. \\nAll date-time fields in responses must include the timezone. An example is below:\\n2017-04-05T10:43:07+00:00")
		@Pattern(regexp = OBPatterns.ISODATETIME)
		private String statusUpdateDateTime;

		@JsonProperty(value ="Currency", required = true)
		@JsonPropertyDescription("Identification of the currency in which the account is held. \\nUsage: Currency should only be used in case one and the same account number covers several currencies\\nand the initiating party needs to identify which currency needs to be used for settlement on the account.")
		@Pattern(regexp = OBPatterns.CURRENCY_CODE)
		private String currency;

		@JsonProperty(value ="AccountType", required = true)
		@JsonPropertyDescription("Specifies the type of account (personal or business).")
		private OBExternalAccountType1Code accountType;

		@JsonProperty(value ="AccountSubType", required = true)
		@JsonPropertyDescription("Specifies the sub type of account (product family group).")
		private OBExternalAccountSubType1Code accountSubType;

		@JsonProperty(value ="Description", required = false)
		@JsonPropertyDescription("Specifies the description of the account type.")
		@Size(min = 1, max = 35)
		private String description;
		
		@JsonProperty(value ="Nickname", required = false)
		@JsonPropertyDescription("The nickname of the account, assigned by the account owner in order to provide an additional means of identification of the account.")
		@Size(min = 1, max = 70)
		private String nickname;

		@JsonProperty(value ="Account", required = false)
		@JsonPropertyDescription("Provides the details to identify an account.")
		private List<OBCashAccount5> account;

		@JsonProperty(value ="Servicer", required = false)
		@JsonPropertyDescription("Party that manages the account on behalf of the account owner, that is manages the registration and booking of entries on the account, calculates balances on the account and provides information about the account.")
		private OBBranchAndFinancialInstitutionIdentification5 servicer;

	}
	
	@JsonRootName("OBCashAccount5")
	@Getter @Setter
	public static class OBCashAccount5 implements Serializable{

		private static final long serialVersionUID = 7456774183425025064L;
		
		@JsonProperty(value ="SchemeName", required = true)
		@JsonPropertyDescription("Name of the identification scheme, in a coded form as published in an external list.")
		private OBExternalAccountIdentification4Code schemeName;
		
		@JsonProperty(value ="Identification", required = true)
		@JsonPropertyDescription("Identification assigned by an institution to identify an account. This identification is known by the account owner.")
		@Size(min = 1, max = 256)
		@Pattern(regexp = OBPatterns.SAIB_OBCashAccount5_IDENTIFICATION)
		private String identification;

		@JsonProperty(value ="Name", required = false)
		@JsonPropertyDescription("The account name is the name or names of the account owner(s) represented at an account level, as displayed by the ASPSP's online channels.\\nNote, the account name is not the product name or the nickname of the account.")
		@Size(min = 1, max = 350)
		private String name;
		
	}
	
	@JsonRootName("OBBranchAndFinancialInstitutionIdentification5")
	@Getter @Setter
	public static class OBBranchAndFinancialInstitutionIdentification5 {

		@JsonProperty(value ="SchemeName", required = true)
		@JsonPropertyDescription("Name of the identification scheme, in a coded form as published in an external list.")
		private OBExternalFinancialInstitutionIdentification4Code schemeName;

		@JsonProperty(value ="Identification", required = true)
		@JsonPropertyDescription("Unique and unambiguous identification of the servicing institution.")
		@Size(min = 1, max = 35)
		@Pattern(regexp = OBPatterns.SAIB_OBBranchAndFinancialInstitutionIdentification5_IDENTIFICATION)
		private String identification;

	}
	
	public enum OBAccountStatus1Code {
		Deleted, Disabled, Enabled, Pending, ProForma
	}
	
	public enum OBExternalAccountType1Code {
		Business, Personal
	}
	
	public enum OBExternalAccountSubType1Code {
		ChargeCard, CreditCard, CurrentAccount, EMoney, Loan, Mortgage, PrePaidCard, Savings
	}

	public enum OBExternalAccountIdentification4Code {
		IBAN
	}
	
	public enum OBExternalFinancialInstitutionIdentification4Code {
		BICFI
	}
	
}
