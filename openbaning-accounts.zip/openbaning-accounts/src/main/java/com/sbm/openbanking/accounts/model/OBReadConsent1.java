package com.sbm.openbanking.accounts.model;

import java.util.List;

import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonRootName;

import lombok.Getter;
import lombok.Setter;

@JsonRootName("")
@Getter @Setter
public class OBReadConsent1 implements OpenBankingType {

	private static final long serialVersionUID = 8020465379022036989L;

	@JsonProperty(value ="Data", required = true)
	private OBReadData1 data;
	
	
	
	@JsonRootName("OBReadData1")
	@Getter @Setter
	public static class OBReadData1 {
		@JsonProperty(value ="Permissions", required = true)
		@JsonPropertyDescription("Specifies the Open Banking account access data types. This is a list of the data clusters being consented by the PSU, and requested for authorisation with the ASPSP.")
		private List<OBExternalPermissions1Code> permissions;

		@JsonProperty(value ="ExpirationDateTime", required = false)
		@JsonPropertyDescription("Specified date and time the permissions will expire. If this is not populated, the permissions will be open ended.")
		@Pattern(regexp = OBPatterns.ISODATETIME)
		private String expirationDateTime;
		
		@JsonProperty(value ="TransactionFromDateTime", required = false)
		@JsonPropertyDescription("Specified start date and time for the transaction query period. If this is not populated, the start date will be open ended, and data will be returned from the earliest available transaction.")
		@Pattern(regexp = OBPatterns.ISODATETIME)
		private String transactionFromDateTime;
		
		@JsonProperty(value ="TransactionToDateTime", required = false)
		@JsonPropertyDescription("Specified end date and time for the transaction query period. If this is not populated, the end date will be open ended, and data will be returned to the latest available transaction.")
		@Pattern(regexp = OBPatterns.ISODATETIME)
		private String transactionToDateTime;
		
		@JsonProperty(value ="Risk", required = true)
		@JsonPropertyDescription("The Risk section is sent by the initiating party to the ASPSP. It is used to specify additional details for risk scoring for Account Info.")
		private OBRisk2 risk;
	}
	
	@JsonRootName("OBRisk2")
	@Getter @Setter
	public static class OBRisk2 {
//		TODO NO OBJECT
	}
	
	public enum OBExternalPermissions1Code {
		ReadAccountsBasic, ReadAccountsDetail, ReadBalances, ReadBeneficiariesBasic, ReadBeneficiariesDetail, ReadDirectDebits, 
		ReadOffers, ReadPAN, ReadParty, ReadPartyPSU, ReadProducts, ReadScheduledPaymentsBasic, ReadScheduledPaymentsDetail,
		ReadStandingOrdersBasic, ReadStandingOrdersDetail, ReadStatementsBasic, ReadStatementsDetail, ReadTransactionsBasic, 
		ReadTransactionsCredits, ReadTransactionsDebits, ReadTransactionsDetail
	}
	
}
