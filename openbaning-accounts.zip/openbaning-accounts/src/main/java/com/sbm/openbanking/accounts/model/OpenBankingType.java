package com.sbm.openbanking.accounts.model;

import java.io.Serializable;

public interface OpenBankingType extends Serializable{

}
