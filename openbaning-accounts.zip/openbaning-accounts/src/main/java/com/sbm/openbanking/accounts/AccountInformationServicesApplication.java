package com.sbm.openbanking.accounts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccountInformationServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccountInformationServicesApplication.class, args);
	}

}
