package com.sbm.openbanking.accounts.api;

import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.Pattern;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;

import com.sbm.openbanking.accounts.model.OBErrorReply;
import com.sbm.openbanking.accounts.model.OBPatterns;
import com.sbm.openbanking.accounts.model.OBReadAccount4;
import com.sbm.openbanking.accounts.model.OBReadAccount4.OBAccount4;
import com.sbm.openbanking.accounts.model.OBReadBalance1;
import com.sbm.openbanking.accounts.model.OBReadBalance1.OBCashBalance1;
import com.sbm.openbanking.accounts.model.OBReadBeneficiary5;
import com.sbm.openbanking.accounts.model.OBReadBeneficiary5.OBBeneficiary5;
import com.sbm.openbanking.accounts.model.OBReadConsent1;
import com.sbm.openbanking.accounts.model.OBReadConsentResponse1;
import com.sbm.openbanking.accounts.model.OBReadTransaction6;
import com.sbm.openbanking.accounts.model.OBReadTransaction6.OBTransaction6;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.ResponseHeader;

/**
 * JAX-RS API endpoint To retrieve account information for bank customers.
 */
@Api("Accounts")
@Component
@Path("/")
@ApiResponses({
		@ApiResponse(code = 400, message = "Bad request", responseHeaders = { @ResponseHeader(name = "x-fapi-interaction-id", description = "An RFC4122 UID used as a correlation id.", response = String.class) }, response = OBErrorReply.class),
		@ApiResponse(code = 401, message = "Unauthorized", responseHeaders = { @ResponseHeader(name = "x-fapi-interaction-id", description = "An RFC4122 UID used as a correlation id.", response = String.class) }),
		@ApiResponse(code = 403, message = "Forbidden", responseHeaders = { @ResponseHeader(name = "x-fapi-interaction-id", description = "An RFC4122 UID used as a correlation id.", response = String.class) }, response = OBErrorReply.class),
		@ApiResponse(code = 404, message = "Not found", responseHeaders = { @ResponseHeader(name = "x-fapi-interaction-id", description = "An RFC4122 UID used as a correlation id.", response = String.class) }),
		@ApiResponse(code = 405, message = "Method Not Allowed", responseHeaders = { @ResponseHeader(name = "x-fapi-interaction-id", description = "An RFC4122 UID used as a correlation id.", response = String.class) }, response = OBErrorReply.class),
		@ApiResponse(code = 406, message = "Not Acceptable", responseHeaders = { @ResponseHeader(name = "x-fapi-interaction-id", description = "An RFC4122 UID used as a correlation id.", response = String.class) }),
		@ApiResponse(code = 415, message = "Unsupported Media Type", responseHeaders = { @ResponseHeader(name = "x-fapi-interaction-id", description = "An RFC4122 UID used as a correlation id.", response = String.class) }),
		@ApiResponse(code = 429, message = "Too Many Requests", responseHeaders = { @ResponseHeader(name = "Retry-After", description = "Number in seconds to wait", response = Integer.class),
				@ResponseHeader(name = "x-fapi-interaction-id", description = "An RFC4122 UID used as a correlation id.", response = String.class) }),
		@ApiResponse(code = 500, message = "Internal Server Error", responseHeaders = {
				@ResponseHeader(name = "x-fapi-interaction-id", description = "An RFC4122 UID used as a correlation id.", response = String.class) }, response = OBErrorReply.class),
		@ApiResponse(code = 503, message = "Service Unavailable", responseHeaders = {
				@ResponseHeader(name = "x-fapi-interaction-id", description = "An RFC4122 UID used as a correlation id.", response = String.class) }, response = OBErrorReply.class), })
public class ApiEndpoint {

	// ********************************************************* Account Access Consents *********************************************************

	@ApiOperation("Create a consent record for the intent given by Bank Customer to TPP to access their Bank Account Details")
	@POST
	@Path("/account-access-consents")
	@Produces(MediaType.APPLICATION_JSON)
	@ApiResponses({ @ApiResponse(code = 200, message = "Account Access Consents", responseHeaders = {
			@ResponseHeader(name = "x-fapi-interaction-id", description = "An RFC4122 UID used as a correlation id.", response = String.class) }, response = OBReadConsentResponse1.class) })
	public Response getAccountAccessConsents(
			@ApiParam(value = "The time when the PSU last logged in with the TPP. \\nAll dates in the HTTP headers are represented as RFC 7231 Full Dates. An example is below: \\nSun, 10 Sep 2017 19:43:31 UTC", required = false) @Pattern(regexp = OBPatterns.FABI_AUTH_DATETIME) @HeaderParam("x-fapi-auth-date") String xFapiAuthDate,
			@ApiParam(value = "The PSU's IP address if the PSU is currently logged in with the TPP.", required = false) @HeaderParam("x-fapi-customer-ip-address") String xFapiCustomerIpAddress,
			@ApiParam(value = "An RFC4122 UID used as a correlation id.", required = false) @HeaderParam("x-fapi-interaction-id") String xFapiInteractionId,
			@ApiParam(value = "An Authorisation Token as per https://tools.ietf.org/html/rfc6750", required = true) @HeaderParam("Authorization") String authorization,
			@ApiParam(value = "OBReadConsent1", required = true) @RequestBody OBReadConsent1 readConsent1) {

		OBReadConsentResponse1 readConsentResponse1 = new OBReadConsentResponse1();
		OBReadConsentResponse1.OBReadDataConsentResponse1 data = new OBReadConsentResponse1.OBReadDataConsentResponse1();
		readConsentResponse1.setData(data);

		return Response.status(Response.Status.OK).entity(readConsentResponse1).type(MediaType.APPLICATION_JSON_TYPE).build();
	}
	
	@ApiOperation("Account Access Consents by Consent Id")
	@GET
	@Path("/account-access-consents/{ConsentId}")
	@Produces(MediaType.APPLICATION_JSON)
	@ApiResponses({ @ApiResponse(code = 200, message = "Account Access Consents by Consent Id", responseHeaders = {
			@ResponseHeader(name = "x-fapi-interaction-id", description = "An RFC4122 UID used as a correlation id.", response = String.class) }, response = OBReadConsentResponse1.class) })
	public Response getAccountAccessConsentsById(
			@ApiParam(value = "ConsentId", required = true) @PathParam("ConsentId") String consentId,
			@ApiParam(value = "The time when the PSU last logged in with the TPP. \\nAll dates in the HTTP headers are represented as RFC 7231 Full Dates. An example is below: \\nSun, 10 Sep 2017 19:43:31 UTC", required = false) @Pattern(regexp = OBPatterns.FABI_AUTH_DATETIME) @HeaderParam("x-fapi-auth-date") String xFapiAuthDate,
			@ApiParam(value = "The PSU's IP address if the PSU is currently logged in with the TPP.", required = false) @HeaderParam("x-fapi-customer-ip-address") String xFapiCustomerIpAddress,
			@ApiParam(value = "An RFC4122 UID used as a correlation id.", required = false) @HeaderParam("x-fapi-interaction-id") String xFapiInteractionId,
			@ApiParam(value = "An Authorisation Token as per https://tools.ietf.org/html/rfc6750", required = true) @HeaderParam("Authorization") String authorization) {
		
		OBReadConsentResponse1 readConsentResponse1 = new OBReadConsentResponse1();
		OBReadConsentResponse1.OBReadDataConsentResponse1 data = new OBReadConsentResponse1.OBReadDataConsentResponse1();
		readConsentResponse1.setData(data);
		
		return Response.status(Response.Status.OK).entity(readConsentResponse1).type(MediaType.APPLICATION_JSON_TYPE).build();
	}
	
	@ApiOperation("Delete Account Access Consents by Consent Id")
	@DELETE
	@Path("/account-access-consents/{ConsentId}")
	@Produces(MediaType.APPLICATION_JSON)
	@ApiResponses({ @ApiResponse(code = 204, message = "Delete Account Access Consents by Consent Id", responseHeaders = {
			@ResponseHeader(name = "x-fapi-interaction-id", description = "An RFC4122 UID used as a correlation id.", response = String.class) }) })
	public Response deleteAccountAccessConsentsById(
			@ApiParam(value = "ConsentId", required = true) @PathParam("ConsentId") String consentId,
			@ApiParam(value = "The time when the PSU last logged in with the TPP. \\nAll dates in the HTTP headers are represented as RFC 7231 Full Dates. An example is below: \\nSun, 10 Sep 2017 19:43:31 UTC", required = false) @Pattern(regexp = OBPatterns.FABI_AUTH_DATETIME) @HeaderParam("x-fapi-auth-date") String xFapiAuthDate,
			@ApiParam(value = "The PSU's IP address if the PSU is currently logged in with the TPP.", required = false) @HeaderParam("x-fapi-customer-ip-address") String xFapiCustomerIpAddress,
			@ApiParam(value = "An RFC4122 UID used as a correlation id.", required = false) @HeaderParam("x-fapi-interaction-id") String xFapiInteractionId,
			@ApiParam(value = "An Authorisation Token as per https://tools.ietf.org/html/rfc6750", required = true) @HeaderParam("Authorization") String authorization) {
		
		return Response.status(Response.Status.NO_CONTENT).type(MediaType.APPLICATION_JSON_TYPE).build();
	}
	

	// ********************************************************* Accounts *********************************************************

	@ApiOperation("Get Accounts")
	@GET
	@Path("/accounts")
	@Produces(MediaType.APPLICATION_JSON)
	@ApiResponses({ @ApiResponse(code = 200, message = "Accounts Read", responseHeaders = {
			@ResponseHeader(name = "x-fapi-interaction-id", description = "An RFC4122 UID used as a correlation id.", response = String.class) }, response = OBReadAccount4.class) })
	public Response getAccounts(
			@ApiParam(value = "The time when the PSU last logged in with the TPP. \\nAll dates in the HTTP headers are represented as RFC 7231 Full Dates. An example is below: \\nSun, 10 Sep 2017 19:43:31 UTC", required = false) @Pattern(regexp = OBPatterns.FABI_AUTH_DATETIME) @HeaderParam("x-fapi-auth-date") String xFapiAuthDate,
			@ApiParam(value = "The PSU's IP address if the PSU is currently logged in with the TPP.", required = false) @HeaderParam("x-fapi-customer-ip-address") String xFapiCustomerIpAddress,
			@ApiParam(value = "An RFC4122 UID used as a correlation id.", required = false) @HeaderParam("x-fapi-interaction-id") String xFapiInteractionId,
			@ApiParam(value = "An Authorisation Token as per https://tools.ietf.org/html/rfc6750", required = true) @HeaderParam("Authorization") String authorization) {

		List<OBAccount4> accounts = new ArrayList<OBAccount4>();
		OBReadAccount4 accountsRes = new OBReadAccount4();
		OBReadAccount4.OBReadDataAccount4 data = new OBReadAccount4.OBReadDataAccount4();
		data.setAccounts(accounts);
		accountsRes.setData(data);

		return Response.status(Response.Status.OK).entity(accountsRes).type(MediaType.APPLICATION_JSON_TYPE).build();
	}

	@ApiOperation("Get Accounts By Account ID")
	@GET
	@Path("/accounts/{AccountId}")
	@Produces(MediaType.APPLICATION_JSON)
	@ApiResponses({ @ApiResponse(code = 200, message = "Get Accounts By Account ID", responseHeaders = {
			@ResponseHeader(name = "x-fapi-interaction-id", description = "An RFC4122 UID used as a correlation id.", response = String.class) }, response = OBReadAccount4.class) })
	public Response getAccountsAccountId(
			@ApiParam(value = "AccountId", required = true) @PathParam("AccountId") @Pattern(regexp = OBPatterns.SAIB_ACCOUNT_ID) String accountId,
			@ApiParam(value = "The time when the PSU last logged in with the TPP. \\nAll dates in the HTTP headers are represented as RFC 7231 Full Dates. An example is below: \\nSun, 10 Sep 2017 19:43:31 UTC", required = false) @Pattern(regexp = OBPatterns.FABI_AUTH_DATETIME) @HeaderParam("x-fapi-auth-date") String xFapiAuthDate,
			@ApiParam(value = "The PSU's IP address if the PSU is currently logged in with the TPP.", required = false) @HeaderParam("x-fapi-customer-ip-address") String xFapiCustomerIpAddress,
			@ApiParam(value = "An RFC4122 UID used as a correlation id.", required = false) @HeaderParam("x-fapi-interaction-id") String xFapiInteractionId,
			@ApiParam(value = "An Authorisation Token as per https://tools.ietf.org/html/rfc6750", required = true) @HeaderParam("Authorization") String authorization) {

		List<OBAccount4> accounts = new ArrayList<OBAccount4>();
		OBReadAccount4 accountsRes = new OBReadAccount4();
		OBReadAccount4.OBReadDataAccount4 data = new OBReadAccount4.OBReadDataAccount4();
		data.setAccounts(accounts);
		accountsRes.setData(data);
		
		return Response.status(Response.Status.OK).entity(accountsRes).type(MediaType.APPLICATION_JSON_TYPE).build();
	}
	

	// ***************************************************** Account Balances *****************************************************

	
	@ApiOperation("Get Account Balances by Account Id")
	@GET
	@Path("/accounts/{AccountId}/balances")
	@Produces(MediaType.APPLICATION_JSON)
	@ApiResponses({ @ApiResponse(code = 200, message = "Get Account Balances by Account Id", responseHeaders = {
			@ResponseHeader(name = "x-fapi-interaction-id", description = "An RFC4122 UID used as a correlation id.", response = String.class) }, response = OBReadBalance1.class) })
	public Response getAccountBalancesById(
			@ApiParam(value = "AccountId", required = true) @PathParam("AccountId") @Pattern(regexp = OBPatterns.SAIB_ACCOUNT_ID) String accountId,
			@ApiParam(value = "The time when the PSU last logged in with the TPP. \\nAll dates in the HTTP headers are represented as RFC 7231 Full Dates. An example is below: \\nSun, 10 Sep 2017 19:43:31 UTC", required = false) @Pattern(regexp = OBPatterns.FABI_AUTH_DATETIME) @HeaderParam("x-fapi-auth-date") String xFapiAuthDate,
			@ApiParam(value = "The PSU's IP address if the PSU is currently logged in with the TPP.", required = false) @HeaderParam("x-fapi-customer-ip-address") String xFapiCustomerIpAddress,
			@ApiParam(value = "An RFC4122 UID used as a correlation id.", required = false) @HeaderParam("x-fapi-interaction-id") String xFapiInteractionId,
			@ApiParam(value = "An Authorisation Token as per https://tools.ietf.org/html/rfc6750", required = true) @HeaderParam("Authorization") String authorization) {

		List<OBCashBalance1> accountBalances = new ArrayList<OBCashBalance1>();
		OBReadBalance1 accountBalancesRes = new OBReadBalance1();
		OBReadBalance1.OBReadDataBalance1 data = new OBReadBalance1.OBReadDataBalance1();
		data.setAccountBalances(accountBalances);
		accountBalancesRes.setData(data);
		
		return Response.status(Response.Status.OK).entity(accountBalancesRes).type(MediaType.APPLICATION_JSON_TYPE).build();
	}
	
	@ApiOperation("Get Account Balances")
	@GET
	@Path("/balances")
	@Produces(MediaType.APPLICATION_JSON)
	@ApiResponses({ @ApiResponse(code = 200, message = "Get Account Balances", responseHeaders = {
			@ResponseHeader(name = "x-fapi-interaction-id", description = "An RFC4122 UID used as a correlation id.", response = String.class) }, response = OBReadBalance1.class) })
	public Response getAccountBalances(
			@ApiParam(value = "The time when the PSU last logged in with the TPP. \\nAll dates in the HTTP headers are represented as RFC 7231 Full Dates. An example is below: \\nSun, 10 Sep 2017 19:43:31 UTC", required = false) @Pattern(regexp = OBPatterns.FABI_AUTH_DATETIME) @HeaderParam("x-fapi-auth-date") String xFapiAuthDate,
			@ApiParam(value = "The PSU's IP address if the PSU is currently logged in with the TPP.", required = false) @HeaderParam("x-fapi-customer-ip-address") String xFapiCustomerIpAddress,
			@ApiParam(value = "An RFC4122 UID used as a correlation id.", required = false) @HeaderParam("x-fapi-interaction-id") String xFapiInteractionId,
			@ApiParam(value = "An Authorisation Token as per https://tools.ietf.org/html/rfc6750", required = true) @HeaderParam("Authorization") String authorization) {
		
		List<OBCashBalance1> accountBalances = new ArrayList<OBCashBalance1>();
		OBReadBalance1 accountBalancesRes = new OBReadBalance1();
		OBReadBalance1.OBReadDataBalance1 data = new OBReadBalance1.OBReadDataBalance1();
		data.setAccountBalances(accountBalances);
		accountBalancesRes.setData(data);
		
		return Response.status(Response.Status.OK).entity(accountBalancesRes).type(MediaType.APPLICATION_JSON_TYPE).build();
	}
	
	
	// ***************************************************** Account Transactions *****************************************************

	
	@ApiOperation("Get Account Transactions by Account Id")
	@GET
	@Path("/accounts/{AccountId}/transactions")
	@Produces(MediaType.APPLICATION_JSON)
	@ApiResponses({ @ApiResponse(code = 200, message = "Get Account Transactions by Account Id", responseHeaders = {
			@ResponseHeader(name = "x-fapi-interaction-id", description = "An RFC4122 UID used as a correlation id.", response = String.class) }, response = OBReadTransaction6.class) })
	public Response getAccountTransactionsById(
			@ApiParam(value = "AccountId", required = true) @PathParam("AccountId") @Pattern(regexp = OBPatterns.SAIB_ACCOUNT_ID) String accountId,
			@ApiParam(value = "The time when the PSU last logged in with the TPP. \\nAll dates in the HTTP headers are represented as RFC 7231 Full Dates. An example is below: \\nSun, 10 Sep 2017 19:43:31 UTC", required = false) @Pattern(regexp = OBPatterns.FABI_AUTH_DATETIME) @HeaderParam("x-fapi-auth-date") String xFapiAuthDate,
			@ApiParam(value = "The PSU's IP address if the PSU is currently logged in with the TPP.", required = false) @HeaderParam("x-fapi-customer-ip-address") String xFapiCustomerIpAddress,
			@ApiParam(value = "An RFC4122 UID used as a correlation id.", required = false) @HeaderParam("x-fapi-interaction-id") String xFapiInteractionId,
			@ApiParam(value = "An Authorisation Token as per https://tools.ietf.org/html/rfc6750", required = true) @HeaderParam("Authorization") String authorization) {

		List<OBTransaction6> accountTransactions = new ArrayList<OBTransaction6>();
		OBReadTransaction6 accountTransactionsRes = new OBReadTransaction6();
		OBReadTransaction6.OBReadDataTransaction6 data = new OBReadTransaction6.OBReadDataTransaction6();
		data.setAccountTransactions(accountTransactions);
		accountTransactionsRes.setData(data);
		
		return Response.status(Response.Status.OK).entity(accountTransactionsRes).type(MediaType.APPLICATION_JSON_TYPE).build();
	}
	
	@ApiOperation("Get Account Transactions")
	@GET
	@Path("/transactions")
	@Produces(MediaType.APPLICATION_JSON)
	@ApiResponses({ @ApiResponse(code = 200, message = "Get Account Transactions", responseHeaders = {
			@ResponseHeader(name = "x-fapi-interaction-id", description = "An RFC4122 UID used as a correlation id.", response = String.class) }, response = OBReadTransaction6.class) })
	public Response getAccountTransactionsById(
			@ApiParam(value = "The time when the PSU last logged in with the TPP. \\nAll dates in the HTTP headers are represented as RFC 7231 Full Dates. An example is below: \\nSun, 10 Sep 2017 19:43:31 UTC", required = false) @Pattern(regexp = OBPatterns.FABI_AUTH_DATETIME) @HeaderParam("x-fapi-auth-date") String xFapiAuthDate,
			@ApiParam(value = "The PSU's IP address if the PSU is currently logged in with the TPP.", required = false) @HeaderParam("x-fapi-customer-ip-address") String xFapiCustomerIpAddress,
			@ApiParam(value = "An RFC4122 UID used as a correlation id.", required = false) @HeaderParam("x-fapi-interaction-id") String xFapiInteractionId,
			@ApiParam(value = "An Authorisation Token as per https://tools.ietf.org/html/rfc6750", required = true) @HeaderParam("Authorization") String authorization) {
		
		List<OBTransaction6> accountTransactions = new ArrayList<OBTransaction6>();
		OBReadTransaction6 accountTransactionsRes = new OBReadTransaction6();
		OBReadTransaction6.OBReadDataTransaction6 data = new OBReadTransaction6.OBReadDataTransaction6();
		data.setAccountTransactions(accountTransactions);
		accountTransactionsRes.setData(data);
		
		return Response.status(Response.Status.OK).entity(accountTransactionsRes).type(MediaType.APPLICATION_JSON_TYPE).build();
	}

	// ***************************************************** Account Beneficiaries *****************************************************
	
	@ApiOperation("Get Account Beneficiaries by Account Id")
	@GET
	@Path("/accounts/{AccountId}/beneficiaries")
	@Produces(MediaType.APPLICATION_JSON)
	@ApiResponses({ @ApiResponse(code = 200, message = "Get Account Beneficiaries by Account Id", responseHeaders = {
			@ResponseHeader(name = "x-fapi-interaction-id", description = "An RFC4122 UID used as a correlation id.", response = String.class) }, response = OBReadBeneficiary5.class) })
	public Response getAccountBeneficiariesById(
			@ApiParam(value = "AccountId", required = true) @PathParam("AccountId") @Pattern(regexp = OBPatterns.SAIB_ACCOUNT_ID) String accountId,
			@ApiParam(value = "The time when the PSU last logged in with the TPP. \\nAll dates in the HTTP headers are represented as RFC 7231 Full Dates. An example is below: \\nSun, 10 Sep 2017 19:43:31 UTC", required = false) @Pattern(regexp = OBPatterns.FABI_AUTH_DATETIME) @HeaderParam("x-fapi-auth-date") String xFapiAuthDate,
			@ApiParam(value = "The PSU's IP address if the PSU is currently logged in with the TPP.", required = false) @HeaderParam("x-fapi-customer-ip-address") String xFapiCustomerIpAddress,
			@ApiParam(value = "An RFC4122 UID used as a correlation id.", required = false) @HeaderParam("x-fapi-interaction-id") String xFapiInteractionId,
			@ApiParam(value = "An Authorisation Token as per https://tools.ietf.org/html/rfc6750", required = true) @HeaderParam("Authorization") String authorization) {
		
		List<OBBeneficiary5> accountBeneficiary5 = new ArrayList<OBBeneficiary5>();
		OBReadBeneficiary5 accountBeneficiariesRes = new OBReadBeneficiary5();
		OBReadBeneficiary5.OBReadDataBeneficiary5 data = new OBReadBeneficiary5.OBReadDataBeneficiary5();
		data.setBeneficiary(accountBeneficiary5);
		accountBeneficiariesRes.setData(data);
		
		return Response.status(Response.Status.OK).entity(accountBeneficiariesRes).type(MediaType.APPLICATION_JSON_TYPE).build();
	}
	
	@ApiOperation("Get Account Beneficiaries")
	@GET
	@Path("/beneficiaries")
	@Produces(MediaType.APPLICATION_JSON)
	@ApiResponses({ @ApiResponse(code = 200, message = "Get Account Beneficiaries", responseHeaders = {
			@ResponseHeader(name = "x-fapi-interaction-id", description = "An RFC4122 UID used as a correlation id.", response = String.class) }, response = OBReadBeneficiary5.class) })
	public Response getAccountBeneficiaries(
			@ApiParam(value = "The time when the PSU last logged in with the TPP. \\nAll dates in the HTTP headers are represented as RFC 7231 Full Dates. An example is below: \\nSun, 10 Sep 2017 19:43:31 UTC", required = false) @Pattern(regexp = OBPatterns.FABI_AUTH_DATETIME) @HeaderParam("x-fapi-auth-date") String xFapiAuthDate,
			@ApiParam(value = "The PSU's IP address if the PSU is currently logged in with the TPP.", required = false) @HeaderParam("x-fapi-customer-ip-address") String xFapiCustomerIpAddress,
			@ApiParam(value = "An RFC4122 UID used as a correlation id.", required = false) @HeaderParam("x-fapi-interaction-id") String xFapiInteractionId,
			@ApiParam(value = "An Authorisation Token as per https://tools.ietf.org/html/rfc6750", required = true) @HeaderParam("Authorization") String authorization) {
		
		List<OBBeneficiary5> accountBeneficiary5 = new ArrayList<OBBeneficiary5>();
		OBReadBeneficiary5 accountBeneficiariesRes = new OBReadBeneficiary5();
		OBReadBeneficiary5.OBReadDataBeneficiary5 data = new OBReadBeneficiary5.OBReadDataBeneficiary5();
		data.setBeneficiary(accountBeneficiary5);
		accountBeneficiariesRes.setData(data);
		
		return Response.status(Response.Status.OK).entity(accountBeneficiariesRes).type(MediaType.APPLICATION_JSON_TYPE).build();
	}

	
}
