package com.sbm.openbanking.accounts.model;

import java.util.List;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.sbm.openbanking.accounts.model.OBReadAccount4.OBCashAccount5;
import com.sbm.openbanking.accounts.model.OBReadTransaction6.OBBranchAndFinancialInstitutionIdentification6;
import com.sbm.openbanking.accounts.model.OBReadTransaction6.OBSupplementaryData1;

import lombok.Getter;
import lombok.Setter;

@JsonRootName("")
@Getter @Setter
public class OBReadBeneficiary5 implements OpenBankingType {

	@JsonProperty(value ="Data", required = true)
	private OBReadDataBeneficiary5 data;
	
	@JsonRootName("OBReadDataBeneficiary5")
	@Getter @Setter
	public static class OBReadDataBeneficiary5 {
		@JsonProperty(value ="Beneficiary", required = false)
		private List<OBBeneficiary5> Beneficiary;
	}
	
	@JsonRootName("OBBeneficiary5")
	@Getter @Setter
	public static class OBBeneficiary5 {
		@JsonProperty(value ="AccountId", required = false)
		@JsonPropertyDescription("A unique and immutable identifier used to identify the account resource. This identifier has no meaning to the account owner.")
		@Size(min = 1, max = 13)
		@Pattern(regexp = OBPatterns.SAIB_ACCOUNT_ID)
		private String accountId;
		
		@JsonProperty(value ="BeneficiaryId", required = false)
		@JsonPropertyDescription("A unique and immutable identifier used to identify the beneficiary resource. This identifier has no meaning to the account owner.")
		@Size(min = 1, max = 40)
		private String beneficiaryId;
		
		@JsonProperty(value ="BeneficiaryType", required = false)
		@JsonPropertyDescription("Specifies the Beneficiary Type.")
		private OBBeneficiaryType1Code beneficiaryType;
		
		@JsonProperty(value ="Reference", required = false)
		@JsonPropertyDescription("Unique reference, as assigned by the creditor, to unambiguously refer to the payment transaction. Usage: If available, the initiating party should provide this reference in the structured remittance information, to enable reconciliation by the creditor upon receipt of the amount of money. If the business context requires the use of a creditor reference or a payment remit identification, and only one identifier can be passed through the end-to-end chain, the creditor's reference or payment remittance identification should be quoted in the end-to-end transaction identification.")
		@Size(min = 1, max = 35)
		private String reference;
		
		@JsonProperty(value ="SupplementaryData", required = false)
		@JsonPropertyDescription("Additional information that cannot be captured in the structured fields and/or any other specific block")
		private OBSupplementaryData1 supplementaryData;
		
		@JsonProperty(value ="CreditorAgent", required = false)
		@JsonPropertyDescription("Party that manages the account on behalf of the account owner, that is manages the registration and booking of entries on the account, calculates balances on the account and provides information about the account. This is the servicer of the beneficiary account.")
		private OBBranchAndFinancialInstitutionIdentification6 creditorAgent;
		
		@JsonProperty(value ="CreditorAccount", required = false)
		@JsonPropertyDescription("Provides the details to identify the beneficiary account.")
		private OBCashAccount5 creditorAccount;
		
	}
	
	public enum OBBeneficiaryType1Code {
		Trusted, Ordinary
	}

	
}
