package com.sbm.openbanking.accounts.model;

import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonClassDescription;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;

@JsonClassDescription("An array of detail error codes, and messages, and URLs to documentation to help remediation.")
public class OBErrorReply implements Serializable {

	@JsonProperty("Code")
	@JsonPropertyDescription("High level textual error code, to help categorize the errors.")
	@Size(min = 1, max = 40)
	private String code;

	@JsonProperty("Id")
	@JsonPropertyDescription("A unique reference for the error instance, for audit purposes, in case of unknown/unclassified errors.")
	@Size(min = 1, max = 40)
	private String id;
	
	@JsonProperty("Message")
	@JsonPropertyDescription("Brief Error message, e.g., 'There is something wrong with the request parameters provided'")
	@Size(min = 1, max = 500)
	private String message;
	
	@JsonProperty("Errors")
	private List<Error> errors;
	
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	public List<Error> getErrors() {
		return errors;
	}
	public void setErrors(List<Error> errors) {
		this.errors = errors;
	}

	
	
	public static class Error {

		@JsonProperty("ErrorCode")
		@JsonPropertyDescription("Low level textual error code, e.g., UK.OBIE.Field.Missing")
		private ErrorCode errorCode;
		
		@JsonProperty("Message")
		@JsonPropertyDescription("A description of the error that occurred. e.g., 'A mandatory field isn't supplied' or 'RequestedExecutionDateTime must be in future'\\nOBIE doesn't standardise this field")
		@Size(min = 1, max = 500)
		private String message;
		
		@JsonProperty("Path")
		@JsonPropertyDescription("Recommended but optional reference to the JSON Path of the field with error, e.g., Data.Initiation.InstructedAmount.Currency")
		@Size(min = 1, max = 500)
		private String path;
		
		@JsonProperty("Url")
		@JsonPropertyDescription("URL to help remediate the problem, or provide more information, or to API Reference, or help etc")
		private String url;
		
		
		public ErrorCode getErrorCode() {
			return errorCode;
		}
		public void setErrorCode(ErrorCode errorCode) {
			this.errorCode = errorCode;
		}
		public String getMessage() {
			return message;
		}
		public void setMessage(String message) {
			this.message = message;
		}
		public String getPath() {
			return path;
		}
		public void setPath(String path) {
			this.path = path;
		}
		public String getUrl() {
			return url;
		}
		public void setUrl(String url) {
			this.url = url;
		}
		
		public enum ErrorCode {
			Field_Expected, Field_Invalid, Field_InvalidDate, Field_Missing, Field_Unexpected,
			Header_Invalid, Header_Missing,
			Reauthenticate,
			Resource_ConsentMismatch, Resource_InvalidConsentStatus, Resource_InvalidFormat, Resource_NotFound,
			Rules_AfterCutOffDateTime, Rules_DuplicateReference,
			Signature_Invalid, Signature_InvalidClaim, Signature_Malformed, Signature_Missing, Signature_MissingClaim, Signature_Unexpected,
			UnexpectedError,
			Unsupported_AccountIdentifier, Unsupported_AccountSecondaryIdentifier, Unsupported_Currency, Unsupported_Frequency, Unsupported_LocalInstrument, Unsupported_Scheme
		}
	}
}
