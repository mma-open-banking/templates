package com.sbm.openbanking.accounts.model;

import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonRootName;

import lombok.Getter;
import lombok.Setter;

@JsonRootName("OBReadBalance1")
@Getter @Setter
public class OBReadBalance1 implements Serializable {
	private static final long serialVersionUID = 4949662200148334400L;

	@JsonProperty(value ="Data", required = true)
	private OBReadDataBalance1 data = new OBReadDataBalance1();
	
	@JsonRootName("OBReadDataBalance1")
	@Getter @Setter
	public static class OBReadDataBalance1 {
		
		@JsonProperty(value ="Balance", required = true)
		@JsonPropertyDescription("Set of elements used to define the balance details.")
		private List<OBCashBalance1> accountBalances;

	}
	
	@JsonRootName("OBCashBalance1")
	@Getter @Setter
	public static class OBCashBalance1 {
		
		@JsonProperty(value ="AccountId", required = true)
		@JsonPropertyDescription("A unique and immutable identifier used to identify the account resource. This identifier has no meaning to the account owner.")
		@Size(min = 1, max = 13)
		@Pattern(regexp = OBPatterns.SAIB_ACCOUNT_ID)
		private String accountId;

		@JsonProperty(value ="CreditDebitIndicator", required = true)
		@JsonPropertyDescription("Indicates whether the balance is a credit or a debit balance. \\nUsage: A zero balance is considered to be a credit balance.")
		private OBCreditDebitCode creditDebitIndicator;

		@JsonProperty(value ="Type", required = true)
		@JsonPropertyDescription("Balance type, in a coded form.")
		private OBBalanceType1Code type;

		@JsonProperty(value ="DateTime", required = true)
		@JsonPropertyDescription("Indicates the date (and time) of the balance.All dates in the JSON payloads are represented in ISO 8601 date-time format. \\nAll date-time fields in responses must include the timezone. An example is below:\\n2017-04-05T10:43:07+00:00")
		@Pattern(regexp = OBPatterns.ISODATETIME)
		private String dateTime;

		@JsonProperty(value ="Amount", required = true)
		@JsonPropertyDescription("Amount of money of the cash balance.")
		private OBActiveOrHistoricCurrencyAndAmount amount;

		@JsonProperty(value ="CreditLine", required = false)
		@JsonPropertyDescription("Set of elements used to provide details on the credit line.")
		private List<OBCreditLine1> creditLine;
		
	}
	
	@JsonRootName("OBActiveOrHistoricCurrencyAndAmount")
	@Getter @Setter
	public static class OBActiveOrHistoricCurrencyAndAmount {
		
		@JsonProperty(value ="Amount", required = true)
		@JsonPropertyDescription("A number of monetary units specified in an active currency where the unit of currency is explicit and compliant with ISO 4217.")
		@Pattern(regexp = OBPatterns.AMOUNT)
		private String amount;

		@JsonProperty(value ="Currency", required = true)
		@JsonPropertyDescription("A code allocated to a currency by a Maintenance Agency under an international identification scheme, as described in the latest edition of the international standard ISO 4217 \\\"Codes for the representation of currencies and funds\\\".")
		@Pattern(regexp = OBPatterns.CURRENCY_CODE)
		private String currency;

	}
	
	@JsonRootName("OBCreditLine1")
	@Getter @Setter
	public static class OBCreditLine1 {

		@JsonProperty(value ="Included", required = true)
		@JsonPropertyDescription("Indicates whether or not the credit line is included in the balance of the account.\\nUsage: If not present, credit line is not included in the balance amount of the account.")
		private Boolean included;

		@JsonProperty(value ="Type", required = false)
		@JsonPropertyDescription("Limit type, in a coded form.")
		private CreditLineType type;

		@JsonProperty(value ="Amount", required = false)
		@JsonPropertyDescription("Amount of money of the credit line.")
		private OBActiveOrHistoricCurrencyAndAmount amount;

	}
	
	public enum OBCreditDebitCode {
		Credit, Debit
	}
	
	public enum OBBalanceType1Code {
		ClosingAvailable, ClosingBooked, ClosingCleared, Expected, ForwardAvailable, Information, InterimAvailable, 
		InterimBooked, InterimCleared, OpeningAvailable, OpeningBooked, OpeningCleared, PreviouslyClosedBooked
	}
	
	public enum CreditLineType {
		Available, Credit, Emergency, Pre_Agreed, Temporary
	}
	
}

