package com.sbm.openbanking.accounts.model;

import java.util.List;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.sbm.openbanking.accounts.model.OBReadConsent1.OBExternalPermissions1Code;
import com.sbm.openbanking.accounts.model.OBReadConsent1.OBRisk2;

import lombok.Getter;
import lombok.Setter;

@JsonRootName("")
@Getter @Setter
public class OBReadConsentResponse1 implements OpenBankingType {

	private static final long serialVersionUID = 8020465379022036989L;

	@JsonProperty(value ="Data", required = true)
	private OBReadDataConsentResponse1 data;
	
	
	@JsonRootName("OBReadDataConsentResponse1")
	@Getter @Setter
	public static class OBReadDataConsentResponse1 {
		@JsonProperty(value ="ConsentId", required = true)
		@JsonPropertyDescription("Unique identification as assigned to identify the account access consent resource.")
		@Size(min = 1, max = 128)
		private String consentId;

		@JsonProperty(value ="CreationDateTime", required = true)
		@JsonPropertyDescription("Date and time at which the resource was created.")
		@Pattern(regexp = OBPatterns.ISODATETIME)
		private String creationDateTime;
		
		@JsonProperty(value ="Status", required = true)
		@JsonPropertyDescription("Specifies the status of consent resource in code form.")
		private OBExternalRequestStatus1Code Status;
		
		@JsonProperty(value ="StatusUpdateDateTime", required = true)
		@JsonPropertyDescription("Date and time at which the resource status was updated.")
		@Pattern(regexp = OBPatterns.ISODATETIME)
		private String statusUpdateDateTime;
		
		@JsonProperty(value ="Permissions", required = true)
		@JsonPropertyDescription("Specifies the Open Banking account access data types. This is a list of the data clusters being consented by the PSU, and requested for authorisation with the ASPSP.")
		private List<OBExternalPermissions1Code> permissions;
		
		@JsonProperty(value ="ExpirationDateTime", required = false)
		@JsonPropertyDescription("Specified date and time the permissions will expire. If this is not populated, the permissions will be open ended.")
		@Pattern(regexp = OBPatterns.ISODATETIME)
		private String expirationDateTime;
		
		@JsonProperty(value ="TransactionFromDateTime", required = false)
		@JsonPropertyDescription("Specified start date and time for the transaction query period. If this is not populated, the start date will be open ended, and data will be returned from the earliest available transaction.")
		@Pattern(regexp = OBPatterns.ISODATETIME)
		private String transactionFromDateTime;
		
		@JsonProperty(value ="TransactionToDateTime", required = false)
		@JsonPropertyDescription("Specified end date and time for the transaction query period. If this is not populated, the end date will be open ended, and data will be returned to the latest available transaction.")
		@Pattern(regexp = OBPatterns.ISODATETIME)
		private String transactionToDateTime;
		
		@JsonProperty(value ="Risk", required = true)
		@JsonPropertyDescription("The Risk section is sent by the initiating party to the ASPSP. It is used to specify additional details for risk scoring for Account Info.")
		private OBRisk2 risk;
	}
	
	public enum OBExternalRequestStatus1Code {
		Authorised, AwaitingAuthorisation, Rejected, Revoked
	}
	
}
