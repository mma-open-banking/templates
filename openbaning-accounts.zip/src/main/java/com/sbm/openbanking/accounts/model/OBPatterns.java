package com.sbm.openbanking.accounts.model;

public class OBPatterns {
	public static final String CURRENCY_CODE = "(SAR|USD|EUR|GPB)";
	public static final String FABI_AUTH_DATETIME =  "(Mon|Tue|Wed|Thu|Fri|Sat|Sun), [0-9]{2} (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) [0-9]{4} [0-9]{2}:[0-9]{2}:[0-9]{2} (GMT|UTC)";
	public static final String AMOUNT = "[0-9]{1,13}[0-9]{1,2}";
	public static final String NUMBER_OF_TRANSACTIONS = "[0-9]{1,15}";
	public static final String COUNTRY_CODE = "[A-Z]{2,2}";
	public static final String ISODATETIME = "(?:[1-9][0-9]{3}-(?:(?:0[1-9]|1[0-2])-(?:0[1-9]|1[0-9]|2[0-8])|(?:0[13-9]|1[0-2])-(?:29|30)|(?:0[13578]|1[02])-31)|(?:[1-9][0-9](?:0[48]|[2468][048]|[13579][26])|(?:[2468][048]|[13579][26])00)-02-29)T(?:[01][0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9](?:Z|[+-][01][0-9]:[0-5][0-9])";

	public static final String SAIB_ACCOUNT_ID = "[0-9]{13}";
	public static final String SAIB_OBCashAccount5_IDENTIFICATION = "[0-9]{13}";
	public static final String SAIB_OBBranchAndFinancialInstitutionIdentification5_IDENTIFICATION = "SIBCSARI[A-Z]{3}";
	
}
